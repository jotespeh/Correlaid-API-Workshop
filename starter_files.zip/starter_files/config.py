

user = 'u38837'
password = 'mgaXgcYff5c6'
database = 'db38837'